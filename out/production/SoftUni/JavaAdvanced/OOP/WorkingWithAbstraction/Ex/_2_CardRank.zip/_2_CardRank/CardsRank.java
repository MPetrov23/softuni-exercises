package JavaAdvanced.OOP.WorkingWithAbstraction.Ex._2_CardRank;

public enum CardsRank {
    ACE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    TEN,
    JACK,
    QUEEN,
    KING;
}

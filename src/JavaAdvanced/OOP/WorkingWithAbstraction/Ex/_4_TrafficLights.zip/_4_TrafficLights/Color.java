package JavaAdvanced.OOP.WorkingWithAbstraction.Ex._4_TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}

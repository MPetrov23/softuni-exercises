package JavaAdvanced.OOP.WorkingWithAbstraction.Ex._1_CardSuit;

public enum Cards {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
